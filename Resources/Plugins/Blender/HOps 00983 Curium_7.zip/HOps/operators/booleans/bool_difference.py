import bpy
from . import operator
from ... preferences import get_preferences


class HOPS_OT_BoolDifference(bpy.types.Operator):
    bl_idname = "hops.bool_difference"
    bl_label = "Hops Difference Boolean"
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = """Cuts mesh using Difference Boolean
LMB - Boolean object set to wire / boolshape (DEFAULT)
LMB + Shift - Set Boolean while keeping solid

Press H for help."""

    boolshape = True

    @classmethod
    def poll(cls, context):
        selected = context.selected_objects
        if all(obj.type == "MESH" for obj in selected):
            return True

    def invoke(self, context, event):
        if event.shift:
            self.boolshape = False
        else:
            self.boolshape = True

        self.execute(context)
        return {'FINISHED'}

    def execute(self, context):
        if len(bpy.context.selected_objects) < 2:
            return {'CANCELLED'}
        else:
            operator.boolean(context, 'DIFFERENCE', boolshape=self.boolshape)
            bpy.context.object.data.use_auto_smooth = True

        return {'FINISHED'}
