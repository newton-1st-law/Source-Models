import bpy

from bpy.utils import register_class, unregister_class

from . import grid

classes = (
    grid.HOPS_MT_Tool_grid)


def register():
    # for cls in classes:
    register_class(grid.HOPS_MT_Tool_grid)


def unregister():
    # for cls in classes:
    unregister_class(grid.HOPS_MT_Tool_grid)
