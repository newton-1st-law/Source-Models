__all__ = ('menu', 'operator', 'panel', 'property', 'utility', 'icon', 'keymap', 'pie', 'topbar')


import bpy

from bpy.utils import register_class, unregister_class

from . import menu, operator, panel, property, keymap, pie, topbar


def register():
    menu.register()
    operator.register()
    panel.register()
    property.register()
    keymap.register()
    pie.register()
    topbar.register()


def unregister():
    menu.unregister()
    operator.unregister()
    panel.unregister()
    property.unregister()
    keymap.unregister()
    pie.unregister()
    topbar.unregister()
