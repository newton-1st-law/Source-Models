import bpy

from bpy.utils import register_class, unregister_class

from . import boolshape

classes = (
    boolshape.HOPS_OT_SELECT_boolshape)


def register():
    # for cls in classes:
    #     register_class(cls)
    register_class(boolshape.HOPS_OT_SELECT_boolshape)


def unregister():
    # for cls in classes:
    #     unregister_class(cls)
    unregister_class(boolshape.HOPS_OT_SELECT_boolshape)
