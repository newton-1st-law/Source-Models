import bpy
import math
import bmesh
from .... preferences import get_preferences
from ... property.preference import property


class HOPS_OT_ADD_bbox(bpy.types.Operator):
    bl_idname = "hops.add_bbox"
    bl_label = "Add smart bbox"
    bl_options = {"REGISTER", "UNDO", "GRAB_CURSOR", "BLOCKING"}
    bl_description = """Create Smart bbox"""

    def execute(self, context):
        verts = [(-1, -1, 0)]
        # verts = [(0, 0, 0)]
        obj = bpy.data.objects.new("Plane", bpy.data.meshes.new("Plane"))

        bpy.ops.object.select_all(action='DESELECT')
        context.collection.objects.link(obj)
        context.view_layer.objects.active = obj
        obj.select_set(True)

        bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

        bm = bmesh.new()
        for v in verts:
            bm.verts.new(v)
        bm.to_mesh(context.object.data)
        bm.free()

        self.add_screw_modifier(obj, 'X', 'HOPS_screw_x')
        self.add_screw_modifier(obj, 'Y', 'HOPS_screw_y', True)
        self.add_mirror_modifier(obj, 'HOPS_mirror')
        self.add_decimate_modifier(obj, 'HOPS_decimate_c')
        self.add_bevel_modifier(obj, True, 12, 0.2, 'HOPS_bevel_d')
        self.add_solidify_modifier(obj, 'HOPS_solidify_z')
        self.add_bevel_modifier(obj, False, 1, 0.07, 'HOPS_bevel_b')
        self.add_bevel_modifier(obj, False, 6, 0.005, 'HOPS_bevel_c')
        self.add_weighted_modifier(obj, 'HOPS_weighted')
        bpy.context.object.data.use_auto_smooth = True
        bpy.context.object.data.auto_smooth_angle = math.radians(30)

        # Todo : Resize is problematic so is resize for dots
        # Todo : This needs bC
        if property.bc():
            property.bc().behavior.sort_decimate = False
            # property.bc().behavior.sort_bevel = True
            # property.bc().behavior.sort_last_bevel = True

        return {"FINISHED"}

    def add_screw_modifier(self, object, axis='X', name='HOPS_screw_x', flip=False):
        screw_modifier = object.modifiers.new(name=name, type="SCREW")
        screw_modifier.angle = math.radians(0)
        screw_modifier.axis = axis
        screw_modifier.steps = 3
        screw_modifier.render_steps = 3
        screw_modifier.screw_offset = 2
        screw_modifier.iterations = 1
        screw_modifier.use_smooth_shade = True
        screw_modifier.use_merge_vertices = True
        screw_modifier.use_normal_flip = flip

    def add_weighted_modifier(self, object, name='HOPS_weighted'):
        modifier = object.modifiers.new('WeightedNormal', 'WEIGHTED_NORMAL')
        modifier.keep_sharp = True

    def add_decimate_modifier(self, object, name='HOPS_decimate_c'):
        modifier = object.modifiers.new('Decimate', 'DECIMATE')
        modifier.angle_limit = math.radians(5)
        modifier.decimate_type = 'DISSOLVE'

    def add_bevel_modifier(self, object, verts, segments, width, name='HOPS_bevel_c'):
        modifier = object.modifiers.new(name=name, type="BEVEL")
        modifier.use_only_vertices = verts
        modifier.limit_method = "ANGLE"
        modifier.angle_limit = math.radians(30)
        modifier.miter_outer = 'MITER_ARC'
        modifier.width = width
        modifier.profile = .5
        modifier.segments = segments
        modifier.loop_slide = get_preferences().property.bevel_loop_slide
        modifier.use_clamp_overlap = False

    def add_solidify_modifier(self, object, name='HOPS_solidify_z'):
        solidify_modifier = object.modifiers.new(name, "SOLIDIFY")
        solidify_modifier.thickness = 2
        solidify_modifier.offset = 1
        solidify_modifier.use_even_offset = True
        solidify_modifier.use_quality_normals = True
        solidify_modifier.use_rim_only = False
        solidify_modifier.show_on_cage = True

    def add_displace_modifier(self, object, axis='X', name='HOPS_displace_x'):
        displace_modifier = object.modifiers.new(name=name, type="DISPLACE")
        displace_modifier.direction = axis
        displace_modifier.strength = -1.0

    def add_mirror_modifier(self, object, name='HOPS_mirror'):
        mirror_modifier = object.modifiers.new(name=name, type="MIRROR")
        mirror_modifier.use_axis[0] = True
        mirror_modifier.use_axis[1] = True
        mirror_modifier.use_bisect_axis[0] = True
        mirror_modifier.use_bisect_axis[1] = True
        #mirror_modifier.use_bisect_flip_axis[0] = True
        #mirror_modifier.use_bisect_flip_axis[1] = True

class HOPS_OT_ADD_box(bpy.types.Operator):
    bl_idname = "hops.add_box"
    bl_label = "Add smart Box"
    bl_options = {"REGISTER", "UNDO", "GRAB_CURSOR", "BLOCKING"}
    bl_description = """Create Smart box"""

    def execute(self, context):
        verts = [(-1, -1, 0)]
        obj = bpy.data.objects.new("Cube", bpy.data.meshes.new("Cube"))

        bpy.ops.object.select_all(action='DESELECT')
        context.collection.objects.link(obj)
        context.view_layer.objects.active = obj
        obj.select_set(True)

        bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

        bm = bmesh.new()
        for v in verts:
            bm.verts.new(v)
        bm.to_mesh(context.object.data)
        bm.free()

        self.add_screw_modifier(obj, 'X', 'HOPS_screw_x')
        self.add_screw_modifier(obj, 'Y', 'HOPS_screw_y', True)
        self.add_solidify_modifier(obj, 'HOPS_solidify_z')
        self.add_mirror_modifier(obj, 'HOPS_mirror')
        self.add_decimate_modifier(obj, 'HOPS_decimate_c')
        bpy.context.object.data.use_auto_smooth = True
        bpy.context.object.data.auto_smooth_angle = math.radians(60)

        return {"FINISHED"}

    def add_screw_modifier(self, object, axis='X', name='HOPS_screw_x', flip=False):
        screw_modifier = object.modifiers.new(name=name, type="SCREW")
        screw_modifier.angle = math.radians(0)
        screw_modifier.axis = axis
        screw_modifier.steps = 2
        screw_modifier.render_steps = 2
        screw_modifier.screw_offset = 2
        screw_modifier.iterations = 1
        screw_modifier.use_smooth_shade = False
        screw_modifier.use_merge_vertices = True
        screw_modifier.use_normal_flip = flip

    def add_displace_modifier(self, object, strength, axis='X', name='HOPS_displace_x'):
        displace_modifier = object.modifiers.new(name=name, type="DISPLACE")
        displace_modifier.direction = axis
        displace_modifier.strength = strength

    def add_solidify_modifier(self, object, name='HOPS_solidify_z'):
        solidify_modifier = object.modifiers.new(name, "SOLIDIFY")
        solidify_modifier.thickness = 2
        solidify_modifier.offset = 1
        solidify_modifier.use_even_offset = True
        solidify_modifier.use_quality_normals = True
        solidify_modifier.use_rim_only = False
        solidify_modifier.show_on_cage = True

    def add_mirror_modifier(self, object, name='HOPS_mirror'):
        mirror_modifier = object.modifiers.new(name=name, type="MIRROR")
        mirror_modifier.use_axis[0] = True
        mirror_modifier.use_axis[1] = True
        mirror_modifier.use_bisect_axis[0] = True
        mirror_modifier.use_bisect_axis[1] = True
        # mirror_modifier.use_bisect_flip_axis[1] = True

    def add_decimate_modifier(self, object, name='HOPS_decimate_c'):
        modifier = object.modifiers.new('Decimate', 'DECIMATE')
        modifier.angle_limit = math.radians(5)
        modifier.decimate_type = 'DISSOLVE'
