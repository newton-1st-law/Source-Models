import bpy
import bmesh
import gpu

from math import cos, sin, pi

from bgl import *
from gpu_extras.batch import batch_for_shader

from mathutils import Vector

from ... utility import addon, screen


class dots:
    handler: None


    def __init__(self, ot, context):
        self.points(ot, context)


    def points(self, ot, context):
        hardflow = context.window_manager.hardflow

        for point in hardflow.dots.points:
            self.point(point)


    def point(self, point):
        preference = addon.preference()
        size = addon.preference().display.dot_size * 0.5 * screen.dpi_factor()

        if point.highlight:
            col = Vector(preference.color.dot_highlight[:])
        else:
            if point.color == 'red':
                col = Vector(preference.color.dot3[:])
            elif point.color == 'yellow':
                col = Vector(preference.color.dot4[:])
            elif point.color == 'green':
                col = Vector(preference.color.dot2[:])
            elif point.color == 'blue':
                col = Vector(preference.color.dot5[:])
            else:
                col = Vector(preference.color.dot[:])

        square_dots = {'boolshape'}

        if point.type in square_dots:
            size *= 0.75
            vertices = (
                (point.location2d[0] - size, point.location2d[1] - size),
                (point.location2d[0] + size, point.location2d[1] - size),
                (point.location2d[0] - size, point.location2d[1] + size),
                (point.location2d[0] + size, point.location2d[1] + size))

            indices = ((0, 1, 2), (2, 1, 3))
        else:
            vertices = [(point.location2d[0], point.location2d[1])]

            for i in range(32):
                index = i + 1
                vertices.append((point.location2d[0] + cos(index * pi * 2 * 0.03125) * size, point.location2d[1] + sin(index * pi * 2 * 0.03125) * size))

            indices = [(0, i + 1, i + 2 if i + 2 < 32 else 1) for i in range(32)]

        if point.type not in square_dots:
            vert_edges = vertices[1:]
            vert_edges.append(vert_edges[6])

            indice_edges = [(0, 1), (1, 2), (2, 3), (3, 4), (4, 5), (5, 6), (6, 7), (7, 8), (8, 9), (9, 10), (10, 11), (11, 12), (12, 13), (13, 14), (14, 15), (15, 16), (16, 17), (17, 18), (18, 19), (19, 20), (20, 21), (21, 22), (22, 23), (23, 24), (24, 25), (25, 26), (26, 27), (27, 28), (28, 29), (29, 30), (30, 31), (31, 32), (0, 32)]

            shader = gpu.shader.from_builtin('2D_UNIFORM_COLOR')
            batch = batch_for_shader(shader, 'LINES', {'pos': vert_edges}, indices=indice_edges)

            shader.bind()
            shader.uniform_float('color', col)

            width = 1

            glEnable(GL_LINE_SMOOTH)
            glEnable(GL_BLEND)
            # glEnable(GL_ALWAYS)
            glLineWidth(width)
            batch.draw(shader)
            glDisable(GL_LINE_SMOOTH)
            glDisable(GL_BLEND)

            del shader
            del batch

        shader = gpu.shader.from_builtin('2D_UNIFORM_COLOR')
        batch = batch_for_shader(shader, 'TRIS', {'pos': vertices}, indices=indices)

        shader.bind()

        if point.type == 'boolshape':
            col[3] = col[3] * point.alpha

        shader.uniform_float('color', col)

        glEnable(GL_BLEND)
        batch.draw(shader)
        glDisable(GL_BLEND)

        del shader
        del batch
