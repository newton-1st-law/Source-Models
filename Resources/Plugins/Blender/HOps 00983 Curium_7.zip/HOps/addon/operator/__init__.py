import bpy


from . import modifier, add, select, tool, topbar


def register():
    modifier.register()
    add.register()
    select.register()
    tool.register()
    topbar.register()


def unregister():
    modifier.unregister()
    add.unregister()
    select.unregister()
    tool.unregister()
    topbar.unregister()
