import bpy

from . utility import addon
from .. utils.addons import addon_exists

keys = []


def register():
    # global keys

    wm = bpy.context.window_manager
    active_keyconfig = wm.keyconfigs.active
    addon_keyconfig = wm.keyconfigs.addon

    kc = addon_keyconfig
    if not kc:
        print('no keyconfig path found, skipped (we must be in batch mode)')
        return

    # register to 3d view mode tab
    km = kc.keymaps.new(name="3D View", space_type="VIEW_3D")

    kmi = km.keymap_items.new("wm.call_menu_pie", "Q", "PRESS", shift=True)
    kmi.properties.name = "HOPS_MT_MainPie"
    keys.append((km, kmi))

    kmi = km.keymap_items.new("wm.call_menu", "Q", "PRESS")
    kmi.properties.name = "HOPS_MT_MainMenu"
    keys.append((km, kmi))

    kmi = km.keymap_items.new("hops.helper", "ACCENT_GRAVE", "PRESS", ctrl=True)
    # kmi = km.keymap_items.new("wm.call_panel", "ACCENT_GRAVE", "PRESS", ctrl=True)
    # kmi.properties.name = "HOPS_PT_Button"
    # kmi.properties.keep_open = True
    keys.append((km, kmi))

    kmi = km.keymap_items.new("wm.call_menu", "M", "PRESS", alt=True)
    kmi.properties.name = "HOPS_MT_MaterialListMenu"
    keys.append((km, kmi))

    kmi = km.keymap_items.new("wm.call_menu", "V", "PRESS", alt=True)
    kmi.properties.name = "HOPS_MT_ViewportSubmenu"
    keys.append((km, kmi))

    kmi = km.keymap_items.new("hops.mirror_mirror_x", 'X', 'PRESS', alt=True, shift=True)
    keys.append((km, kmi))
    kmi = km.keymap_items.new("hops.mirror_mirror_y", 'Y', 'PRESS', alt=True, shift=True)
    keys.append((km, kmi))
    kmi = km.keymap_items.new("hops.mirror_mirror_z", 'Z', 'PRESS', alt=True, shift=True)
    keys.append((km, kmi))
    kmi = km.keymap_items.new("hops.mirror_gizmo", 'X', 'PRESS', alt=True)
    keys.append((km, kmi))
    kmi = km.keymap_items.new("hops.bevel_helper", 'B', 'PRESS', ctrl=True, shift=True)
    keys.append((km, kmi))

    km = kc.keymaps.new(name='Object Mode', space_type='EMPTY')

    kmi = km.keymap_items.new("hops.bool_union", 'NUMPAD_PLUS', 'PRESS', ctrl=True, shift=False)
    keys.append((km, kmi))
    kmi = km.keymap_items.new("hops.bool_difference", 'NUMPAD_MINUS', 'PRESS', ctrl=True, shift=False)
    keys.append((km, kmi))
    kmi = km.keymap_items.new("hops.slash", 'NUMPAD_SLASH', 'PRESS', ctrl=True, shift=False)
    keys.append((km, kmi))

    km = kc.keymaps.new(name='Mesh', space_type='EMPTY')

    kmi = km.keymap_items.new("hops.edit_bool_union", 'NUMPAD_PLUS', 'PRESS', ctrl=True, shift=False, alt=True)
    keys.append((km, kmi))
    kmi = km.keymap_items.new("hops.edit_bool_difference", 'NUMPAD_MINUS', 'PRESS', ctrl=True, shift=False, alt=True)

    keys.append((km, kmi))

    if addon_exists('mira_tools'):
        kmi = km.keymap_items.new("mesh.curve_stretch", 'ACCENT_GRAVE', 'PRESS', ctrl=True, alt=False, shift=True)
        keys.append((km, kmi))

    km = kc.keymaps.new(name="Pose", space_type="EMPTY", region_type="WINDOW")

    kmi = km.keymap_items.new("hops.helper", "ACCENT_GRAVE", "PRESS", ctrl=True)
    keys.append((km, kmi))

    km = kc.keymaps.new(name="Armature", space_type="EMPTY", region_type="WINDOW")

    kmi = km.keymap_items.new("hops.helper", "ACCENT_GRAVE", "PRESS", ctrl=True)
    keys.append((km, kmi))


    # Activate tool
    km = kc.keymaps.new(name='3D View', space_type='VIEW_3D')

    kmi = km.keymap_items.new(idname='hardflow.topbar_activate', type='W', value='PRESS', alt=True, shift=True)
    keys.append((km, kmi))

    # Active Tool
    for kc in (active_keyconfig, addon_keyconfig):
        km = kc.keymaps.new(name='3D View Tool: Hops', space_type='VIEW_3D')

        kmi = km.keymap_items.new(idname='wm.call_menu_pie', type='D', value='PRESS')
        kmi.properties.name = 'Hardflow_MT_pie'

        # Display dots
        kmi = km.keymap_items.new(idname='hardflow_om.display', type='LEFT_CTRL', value='PRESS')

        kmi = km.keymap_items.new(idname='hardflow_om.display', type='RIGHT_CTRL', value='PRESS')

        kmi = km.keymap_items.new(idname='hardflow_om.display', type='OSKEY', value='PRESS')

    # Active Tool
    for kc in (active_keyconfig, addon_keyconfig):
        km = kc.keymaps.new(name='3D View Tool: Hardflow', space_type='VIEW_3D')

        # Pie
        kmi = km.keymap_items.new(idname='wm.call_menu_pie', type='D', value='PRESS')
        kmi.properties.name = 'Hardflow_MT_pie'

        # Display dots
        kmi = km.keymap_items.new(idname='hardflow.display', type='LEFT_CTRL', value='PRESS')

        kmi = km.keymap_items.new(idname='hardflow_om.display', type='RIGHT_CTRL', value='PRESS')

        kmi = km.keymap_items.new(idname='hardflow.display', type='OSKEY', value='PRESS')

    del active_keyconfig
    del addon_keyconfig


def unregister():
    # global keys

    for km, kmi in keys:
        km.keymap_items.remove(kmi)

    keys.clear()
