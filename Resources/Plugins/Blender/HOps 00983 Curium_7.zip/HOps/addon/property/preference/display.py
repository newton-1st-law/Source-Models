import bpy

from bpy.types import PropertyGroup
from bpy.props import BoolProperty, IntProperty, FloatProperty

from ... utility import names


class hardflow(PropertyGroup):

    dot_size: IntProperty(
        name = 'Dot Size',
        description = 'Dot size',
        soft_min = 5,
        soft_max = 50,
        default = 7)

    dot_detect: IntProperty(
        name = 'Dot Detection',
        description = 'Dot detection size',
        soft_min = 1,
        soft_max = 10,
        default = 7)

    dot_side_offset: FloatProperty(
        name = 'Dot offset',
        description = 'Dot side offset',
        soft_min = 0.5,
        soft_max = 5.0,
        default = 1.9)

    dot_corner_offset: FloatProperty(
        name = 'Dot Corner offset',
        description = 'Dot corner offset',
        soft_min = 0.5,
        soft_max = 5.0,
        default = 1.5)

    display_corner: IntProperty(
        name = 'Dot Display Corner',
        description = 'Dot display corner',
        soft_min = 0,
        soft_max = 7,
        default = 2)

    dot_boolshape_fade_distance: FloatProperty(
        name = 'Boolshape Fade distance',
        description = 'Fade distance for boolshape dots',
        default = 2.5)

    display_smartshape: BoolProperty(
        name = 'Display Smartshape Row',
        description = 'Display Smartshape Row',
        default = True)

    display_modifiers: BoolProperty(
        name = 'Display Modifiers Row',
        description = 'Display Modifiers Row',
        default = True)

    display_misc: BoolProperty(
        name = 'Display Misc Row',
        description = 'Display Misc Row',
        default = True)

def label_row(path, prop, row, label=''):
    row.label(text=label if label else names[prop])
    row.prop(path, prop, text='')


def draw(preference, context, layout):

    label_row(preference.display, 'dot_size', layout.row(), 'Dot Size')
    label_row(preference.display, 'dot_detect', layout.row(), 'Dot Detection')
    label_row(preference.display, 'dot_side_offset', layout.row(), 'Dot side OffSet')
    label_row(preference.display, 'dot_corner_offset', layout.row(), 'Dot corner OffSet')
    label_row(preference.display, 'display_corner', layout.row(), 'Dot Display Corner')
    label_row(preference.display, 'display_smartshape', layout.row(), 'Display Smartshape Row')
    label_row(preference.display, 'display_modifiers', layout.row(), 'Display Modifiers Row')
    label_row(preference.display, 'display_misc', layout.row(), 'Display Misc Row')
