import bpy
import textwrap

from bpy.types import PropertyGroup
from bpy.props import BoolProperty, IntProperty

from ... utility import names

import rna_keymap_ui


def get_hotkey_entry_item(km, kmi_name, kmi_value, properties):
    for i, km_item in enumerate(km.keymap_items):
        if km.keymap_items.keys()[i] == kmi_name:
            if properties == 'name':
                if km.keymap_items[i].properties.name == kmi_value:
                    return km_item
            elif properties == 'tab':
                if km.keymap_items[i].properties.tab == kmi_value:
                    return km_item
            elif properties == 'none':
                return km_item
    return None


def draw(preference, context, layout):

    box = layout.box()
    split = box.split()
    col = split.column()
    col.label(text='Do not remove hotkeys, disable them instead.')
    col.separator()
    col.label(text='Hotkeys')

    col.separator()

    wm = bpy.context.window_manager
    kc = wm.keyconfigs.user

    col.label(text='menus:')

    col.separator()
    km = kc.keymaps['3D View']
    kmi = get_hotkey_entry_item(km, 'wm.call_menu_pie', 'HOPS_MT_MainPie', 'name')
    if kmi:
        col.context_pointer_set("keymap", km)
        rna_keymap_ui.draw_kmi([], kc, km, kmi, col, 0)
    else:
        col.label(text="No hotkey entry found")
        col.label(text="restore hotkeys from interface tab")

    col.separator()
    km = kc.keymaps['3D View']
    kmi = get_hotkey_entry_item(km, 'wm.call_menu', 'HOPS_MT_MainMenu', 'name')
    if kmi:
        col.context_pointer_set("keymap", km)
        rna_keymap_ui.draw_kmi([], kc, km, kmi, col, 0)
    else:
        col.label(text="No hotkey entry found")
        col.label(text="restore hotkeys from interface tab")

    col.separator()
    km = kc.keymaps['3D View']
    kmi = get_hotkey_entry_item(km, 'hops.helper', 'none', 'none')
    # kmi = get_hotkey_entry_item(km, 'hops.helper', 'MODIFIERS', 'none')
    if kmi:
        col.context_pointer_set("keymap", km)
        rna_keymap_ui.draw_kmi([], kc, km, kmi, col, 0)
    else:
        col.label(text="No hotkey entry found")
        col.label(text="restore hotkeys from interface tab")

    col.separator()
    km = kc.keymaps['3D View']
    kmi = get_hotkey_entry_item(km, 'hops.bevel_helper', 'MODIFIERS', 'none')
    if kmi:
        col.context_pointer_set("keymap", km)
        rna_keymap_ui.draw_kmi([], kc, km, kmi, col, 0)
    else:
        col.label(text="No hotkey entry found")
        col.label(text="restore hotkeys from interface tab")

    col.separator()
    km = kc.keymaps['3D View']
    kmi = get_hotkey_entry_item(km, 'wm.call_menu', 'HOPS_MT_MaterialListMenu', 'name')
    if kmi:
        col.context_pointer_set("keymap", km)
        rna_keymap_ui.draw_kmi([], kc, km, kmi, col, 0)
    else:
        col.label(text="No hotkey entry found")
        col.label(text="restore hotkeys from interface tab")

    col.separator()
    km = kc.keymaps['3D View']
    kmi = get_hotkey_entry_item(km, 'wm.call_menu', 'HOPS_MT_ViewportSubmenu', 'name')
    if kmi:
        col.context_pointer_set("keymap", km)
        rna_keymap_ui.draw_kmi([], kc, km, kmi, col, 0)
    else:
        col.label(text="No hotkey entry found")
        col.label(text="restore hotkeys from interface tab")

    col.separator()
    col.label(text='operators:')

    col.separator()
    km = kc.keymaps['3D View']
    kmi = get_hotkey_entry_item(km, 'hops.mirror_gizmo', 'none', 'none')
    if kmi:
        col.context_pointer_set("keymap", km)
        rna_keymap_ui.draw_kmi([], kc, km, kmi, col, 0)
    else:
        col.label(text="No hotkey entry found")
        col.label(text="restore hotkeys from interface tab")

    col.separator()
    km = kc.keymaps['3D View']
    kmi = get_hotkey_entry_item(km, 'hops.mirror_mirror_x', 'none', 'none')
    if kmi:
        col.context_pointer_set("keymap", km)
        rna_keymap_ui.draw_kmi([], kc, km, kmi, col, 0)
    else:
        col.label(text="No hotkey entry found")
        col.label(text="restore hotkeys from interface tab")

    col.separator()
    km = kc.keymaps['3D View']
    kmi = get_hotkey_entry_item(km, 'hops.mirror_mirror_y', 'none', 'none')
    if kmi:
        col.context_pointer_set("keymap", km)
        rna_keymap_ui.draw_kmi([], kc, km, kmi, col, 0)
    else:
        col.label(text="No hotkey entry found")
        col.label(text="restore hotkeys from interface tab")

    col.separator()
    km = kc.keymaps['3D View']
    kmi = get_hotkey_entry_item(km, 'hops.mirror_mirror_z', 'none', 'none')
    if kmi:
        col.context_pointer_set("keymap", km)
        rna_keymap_ui.draw_kmi([], kc, km, kmi, col, 0)
    else:
        col.label(text="No hotkey entry found")
        col.label(text="restore hotkeys from interface tab")

    col.separator()
    col.label(text='booleans:')
    col.separator()
    km = kc.keymaps['Object Mode']
    kmi = get_hotkey_entry_item(km, 'hops.bool_union', 'none', 'none')
    if kmi:
        col.context_pointer_set("keymap", km)
        rna_keymap_ui.draw_kmi([], kc, km, kmi, col, 0)
    else:
        col.label(text="No hotkey entry found")
        col.label(text="restore hotkeys from interface tab")

    col.separator()
    km = kc.keymaps['Object Mode']
    kmi = get_hotkey_entry_item(km, 'hops.bool_difference', 'none', 'none')
    if kmi:
        col.context_pointer_set("keymap", km)
        rna_keymap_ui.draw_kmi([], kc, km, kmi, col, 0)
    else:
        col.label(text="No hotkey entry found")
        col.label(text="restore hotkeys from interface tab")

    col.separator()
    km = kc.keymaps['Object Mode']
    kmi = get_hotkey_entry_item(km, 'hops.slash', 'none', 'none')
    if kmi:
        col.context_pointer_set("keymap", km)
        rna_keymap_ui.draw_kmi([], kc, km, kmi, col, 0)
    else:
        col.label(text="No hotkey entry found")
        col.label(text="restore hotkeys from interface tab")

    col.separator()
    km = kc.keymaps['Mesh']
    kmi = get_hotkey_entry_item(km, 'hops.edit_bool_union', 'none', 'none')
    if kmi:
        col.context_pointer_set("keymap", km)
        rna_keymap_ui.draw_kmi([], kc, km, kmi, col, 0)
    else:
        col.label(text="No hotkey entry found")
        col.label(text="restore hotkeys from interface tab")

    col.separator()
    km = kc.keymaps['Mesh']
    kmi = get_hotkey_entry_item(km, 'hops.edit_bool_difference', 'none', 'none')
    if kmi:
        col.context_pointer_set("keymap", km)
        rna_keymap_ui.draw_kmi([], kc, km, kmi, col, 0)
    else:
        col.label(text="No hotkey entry found")
        col.label(text="restore hotkeys from interface tab")

    col.separator()
    col.label(text='External Support:')
    if addon_exists('mira_tools'):
        col.separator()
        km = kc.keymaps['Mesh']
        kmi = get_hotkey_entry_item(km, 'mesh.curve_stretch', 'none', 'none')
        if kmi:
            col.context_pointer_set("keymap", km)
            rna_keymap_ui.draw_kmi([], kc, km, kmi, col, 0)
        else:
            col.label(text="No hotkey entry found")
            col.label(text="restore hotkeys from interface tab")
    else:
        col.label(text="nothing to see here")


def addon_exists(name):
    for addon_name in bpy.context.preferences.addons.keys():
        if name in addon_name: return True
    return False
