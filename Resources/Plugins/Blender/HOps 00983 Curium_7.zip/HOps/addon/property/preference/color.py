import bpy

from mathutils import Vector

from bpy.types import PropertyGroup
from bpy.props import BoolProperty, FloatVectorProperty, FloatProperty

from ... utility import names


class hops(PropertyGroup):

    wire: FloatVectorProperty(
        name = names['wire'],
        description = 'Color of the shape\'s wire',
        size = 4,
        min = 0,
        max = 1,
        subtype='COLOR',
        default = (0.0, 0.0, 0.0, 0.33))

    show_shape_wire: FloatVectorProperty(
        name = names['show_shape_wire'],
        description = 'Color of the shape\'s wire when the object is to be shown',
        size = 4,
        min = 0,
        max = 1,
        subtype='COLOR',
        default = (0.23, 0.7, 0.15, 0.33))

    dot2: FloatVectorProperty(
        name = 'Dot 2',
        description = 'Color of Dot 2',
        size = 4,
        min = 0,
        max = 1,
        subtype='COLOR',
        default = (0.35, 1, 0.29, 0.9))

    dot3: FloatVectorProperty(
        name = 'Dot 3',
        description = 'Color of Dot 3',
        size = 4,
        min = 0,
        max = 1,
        subtype='COLOR',
        default = (1, 0.133, 0.133, 0.9))

    dot4: FloatVectorProperty(
        name = 'Dot 4',
        description = 'Color of Dot 4',
        size = 4,
        min = 0,
        max = 1,
        subtype='COLOR',
        default = (1, 0.9, 0.03, 0.9))

    dot5: FloatVectorProperty(
        name = 'Dot 5',
        description = 'Color of Dot 5',
        size = 4,
        min = 0,
        max = 1,
        subtype='COLOR',
        default = (0.32, 0.67, 1, 0.9))

    dot: FloatVectorProperty(
        name = names['dot'],
        description = 'Color of snapping points',
        size = 4,
        min = 0,
        max = 1,
        subtype='COLOR',
        default = (0.4, 1, 0.9, 0.9))

    dot_highlight: FloatVectorProperty(
        name = names['dot_highlight'],
        description = 'Color of snapping points highlighted',
        size = 4,
        min = 0,
        max = 1,
        subtype='COLOR',
        default = (1, 0.597, 0.133, 0.9))

    enable_tool_overlays: BoolProperty(
        name='Enable tool overlays',
        description='Enable tool overlays',
        default=True)

    Hops_text_color: FloatVectorProperty(
        name="",
        default=Vector((0.6, 0.6, 0.6, 0.9)),
        size=4,
        min=0, max=1,
        subtype='COLOR')

    Hops_text2_color: FloatVectorProperty(
        name="",
        default=Vector((0.6, 0.6, 0.6, 0.9)),
        size=4,
        min=0, max=1,
        subtype='COLOR')

    Hops_border_color: FloatVectorProperty(
        name="",
        default=Vector((0.235, 0.235, 0.235, 0.8)),
        size=4,
        min=0, max=1,
        subtype='COLOR'
        )

    Hops_border2_color: FloatVectorProperty(
        name="",
        default=Vector((0.692, 0.298, 0.137, 0.718)),
        size=4,
        min=0, max=1,
        subtype='COLOR'
        )

    Hops_logo_color: FloatVectorProperty(
        name="",
        default=(0.448, 0.448, 0.448, 0.1),
        size=4,
        min=0, max=1,
        subtype='COLOR'
        )

    Hops_logo_color_csharp: FloatVectorProperty(
        name="",
        default=(1, 0.597, 0.133, 0.9),
        size=4,
        min=0, max=1,
        subtype='COLOR'
        )

    Hops_logo_color_cstep: FloatVectorProperty(
        name="",
        default=(0.29, 0.52, 1.0, 0.9),
        size=4,
        min=0, max=1,
        subtype='COLOR'
        )

    Hops_logo_color_boolshape2: FloatVectorProperty(
        name="",
        default=(1, 0.133, 0.133, 0.53),
        size=4,
        min=0, max=1,
        subtype='COLOR'
        )

    Hops_logo_color_boolshape: FloatVectorProperty(
        name="",
        default=(0.35, 1, 0.29, 0.53),
        size=4,
        min=0, max=1,
        subtype='COLOR'
        )

    Hops_hud_color: FloatVectorProperty(
        name="",
        default=(0.17, 0.17, 0.17, 1),
        size=4,
        min=0, max=1,
        subtype='COLOR'
        )

    Hops_hud_text_color: FloatVectorProperty(
        name="",
        default=(0.831, 0.831, 0.831, 1),
        size=4,
        min=0, max=1,
        subtype='COLOR'
        )

    Hops_hud_help_color: FloatVectorProperty(
        name="",
        default=(1, 0.598, 0.111, 0.7),
        size=4,
        min=0, max=1,
        subtype='COLOR'
        )

    Hops_display_logo: BoolProperty(name="Dispalay Logo", default=False)

    Hops_logo_size: FloatProperty(
        name="HardOps Indicator Size",
        description="BoxCutter indicator size",
        default=2, min=0, max=100)

    Hops_logo_x_position: FloatProperty(
        name="HardOps Indicator X Position",
        description="BoxCutter Indicator X Position",
        default=-203)

    Hops_logo_y_position: FloatProperty(
        name="HardOps Indicator Y Position",
        description="BoxCutter Indicator Y Position",
        default=19)

    Hops_mirror_modal_scale: FloatProperty(
        name="Modal Mirror Operators Scale",
        description="Modal Mirror Operators Scale",
        default=5, min=0.1, max=100
        )

    Hops_mirror_modal_sides_scale: FloatProperty(
        name="Modal Mirror Operators Sides Scale",
        description="Modal Mirror Operators Sides Scale",
        default=0.20, min=0.01, max=0.99)


def label_row(path, prop, row, label=''):
    row.label(text=label if label else names[prop])
    row.prop(path, prop, text='')


def draw(preference, context, layout):
    layout.label(text='Hardops Drawing:')

    label_row(preference.color, 'enable_tool_overlays', layout.row(), label='Enable Overlays')
    layout.separator()
    layout.separator()
    layout.label(text='Modal:')
    label_row(preference.color, 'Hops_text_color', layout.row(), label='Main Text Color')
    label_row(preference.color, 'Hops_text2_color', layout.row(), label='Secoundary Text Color')
    label_row(preference.color, 'Hops_border_color', layout.row(), label='Border Color')
    label_row(preference.color, 'Hops_border2_color', layout.row(), label='Secondary Border Color')
    layout.separator()
    layout.separator()
    layout.label(text='Logo:')
    label_row(preference.color, 'Hops_display_logo', layout.row(), label='Display Logo')
    label_row(preference.color, 'Hops_logo_color', layout.row(), label='Logo Color')
    label_row(preference.color, 'Hops_logo_color_csharp', layout.row(), label='Csharp Color')
    label_row(preference.color, 'Hops_logo_color_cstep', layout.row(), label='Cstep Color')
    label_row(preference.color, 'Hops_logo_color_boolshape', layout.row(), label='Boolshape Color')
    label_row(preference.color, 'Hops_logo_color_boolshape2', layout.row(), label='Boolshape2 Color')
    label_row(preference.color, 'Hops_logo_size', layout.row(), label='Logo Size')
    label_row(preference.color, 'Hops_logo_x_position', layout.row(), label='Logo X Position')
    label_row(preference.color, 'Hops_logo_y_position', layout.row(), label='Logo Y Position')
    layout.separator()
    layout.separator()
    layout.label(text='Hud:')
    label_row(preference.color, 'Hops_hud_color', layout.row(), label='Hud Color')
    label_row(preference.color, 'Hops_hud_text_color', layout.row(), label='Hud Text Color')
    label_row(preference.color, 'Hops_hud_help_color', layout.row(), label='Hud Help Color')
    layout.separator()
    layout.separator()
    layout.label(text='Gizmo')
    label_row(preference.color, 'Hops_mirror_modal_scale', layout.row(), label='modal mirror scale')
    label_row(preference.color, 'Hops_mirror_modal_sides_scale', layout.row(), label='modal mirror sides scale')

    layout.separator()
    layout.separator()
    layout.label(text='Active tool:')
    label_row(preference.color, 'wire', layout.row())
    label_row(preference.color, 'show_shape_wire', layout.row())
    label_row(preference.color, 'dot', layout.row())
    label_row(preference.color, 'dot_highlight', layout.row())
