import bpy
import os

from math import radians
from mathutils import Vector

from bpy.types import PropertyGroup
from bpy.props import BoolProperty, FloatVectorProperty, FloatProperty, StringProperty, EnumProperty, IntProperty

from .... preferences import get_preferences, get_addon_name

from ... utility import addon, names

def update_HardOps_Panel_Tools(self, context):
    panel = getattr(bpy.types, "hops_main_panel", None)
    if panel is not None:
        bpy.utils.unregister_class(panel)
        panel.bl_category = get_preferences().toolbar_category_name
        bpy.utils.register_class(panel)


def category_name_changed(self, context):
    category = get_preferences().toolbar_category_name
    change_hard_ops_category(category)

# edit mode properties

booleans_modes = [
    ("BMESH", "Bmesh", ""),
    ("CARVE", "Carve", "")]

settings_tabs_items = [
    ("UI", "UI", ""),
    ("DRAWING", "Drawing", ""),
    ("INFO", "Info", ""),
    ("KEYMAP", "Keymap", ""),
    ("LINKS", "Links / Help", ""),
    ("ADDONS", "Addons", "")]

mirror_modes = [
    ("MODIFIER", "Mod", ""),
    ("BISECT", "Bisect", ""),
    ("SYMMETRY", "Symmetry", "")]

mirror_modes_multi = [
    ("VIA_ACTIVE", "Mod", ""),
    ("MULTI SYMMETRY", "Symmetry", "")]

mirror_direction = [
    ("-", "-", ""),
    ("+", "+", "")]

symmetrize_type = [
    ("DEFAULT", "Default", ""),
    ("Machin3", "Machin3", "")]


sort_options = (
    'sort_modifiers',
    'sort_bevel',
    'sort_bevel_last',
    'sort_weighted_normal',
    'sort_array',
    'sort_mirror',
    'sort_solidify',
    'sort_triangulate',
    'sort_simple_deform',
    'sort_decimate')

def bc():
    wm = bpy.context.window_manager

    if hasattr(wm, 'bc'):
        return bpy.context.preferences.addons[wm.bc.addon].preferences

    return False


def kitops():
    wm = bpy.context.window_manager

    if hasattr(wm, 'kitops'):
        return bpy.context.preferences.addons[wm.kitops.addon].preferences

    return False


def sync_sort(prop, context):
    for option in sort_options:

        if bc():
            bc().behavior[option] = getattr(bc().behavior, option)

        if kitops():
            kitops()[option] = getattr(kitops(), option)


class hops(PropertyGroup):

    bl_idname = get_addon_name()

    debug: BoolProperty(name="debug", default=False)

    # not shown in pref
    show_presets: BoolProperty(
        name = "Show Presets",
        description = "Show presets in helper",
        default = True)

    decalmachine_fix: BoolProperty(name="Use Setup For DECALmachine", default=False)

    adaptivemode: BoolProperty("Adaptive Segments", default=False)
    adaptiveoffset: FloatProperty("Adaptive Offset", default=10, min=0)
    adaptivewidth: BoolProperty("Adaptive Segments", default=False)

    auto_bweight: BoolProperty("auto bweight", default=False)
    bevel_profile: FloatProperty("default bevel profile", default=0.70, min=0, max=1)

    keep_cutin_bevel: BoolProperty(name="Keep Cut In Bevel", default=True)
    force_array_reset_on_init: BoolProperty(name="Force Array Reset", default=False)
    force_array_apply_scale_on_init: BoolProperty(name="Force Array Apply Scale", default=False)
    force_thick_reset_solidify_init: BoolProperty(name="Force Reset Solidify", default=False)

    meshclean_mode: EnumProperty(name="Mode",
                                 description="",
                                 items=[('ACTIVE', "Active", "Effect all the active object geometry"),
                                        ('SELECTED', "Selected", "Effect only selected geometry or selected objects geometry"),
                                        ('VISIBLE', "Visible", "Effect only visible geometry")],
                                 default='ACTIVE')

    meshclean_dissolve_angle: FloatProperty(name="Limited Dissolve Angle",
                                            default=radians(0.5),
                                            min=radians(0),
                                            max=radians(30),
                                            subtype="ANGLE")
    meshclean_remove_threshold: FloatProperty(name="Remove Threshold Amount",
                                              description="Remove Double Amount",
                                              default=0.001,
                                              min=0.0001,
                                              max=1.00)
    meshclean_unhide_behavior: BoolProperty(default=True)
    meshclean_delete_interior: BoolProperty(default=False)


    sharp_use_crease: BoolProperty(name="Allow Sharpening To Use Crease", default=False)
    sharp_use_bweight: BoolProperty(name="Allow Sharpening To Use Bevel Weight", default=True)
    sharp_use_seam: BoolProperty(name="Allow Sharpening To Use Seams", default=False)
    sharp_use_sharp: BoolProperty(name="Allow Sharpening To Use Sharp Edges", default=True)


    sort_modifiers: BoolProperty(name="Sort Modifiers", update=sync_sort, default=True)
    sort_bevel_last: BoolProperty(name="Sort Bevel Last", update=sync_sort, default=False)
    sort_bevel: BoolProperty(name="Sort Bevel", update=sync_sort, default=True)
    sort_solidify: BoolProperty(name='Sort Solidify', update=sync_sort, default=False)
    sort_array: BoolProperty(name="Sort Array", update=sync_sort, default=True)
    sort_mirror: BoolProperty(name="Sort Mirror", update=sync_sort, default=True)
    sort_weighted_normal: BoolProperty(name="Sort Weighted Normal", update=sync_sort, default=True)
    sort_simple_deform: BoolProperty(name="Sort Simple Deform", update=sync_sort, default=True)
    sort_triangulate: BoolProperty(name="Sort Triangulate", update=sync_sort, default=True)
    sort_decimate: BoolProperty(name="Sort Decimate", update=sync_sort, default=False)


    workflow: EnumProperty(name="Mode",
                           description="",
                           items=[('DESTRUCTIVE', "Destructive", ""),
                                  ('NONDESTRUCTIVE', "NonDestructive", "")],
                           default='NONDESTRUCTIVE')

    workflow_mode: EnumProperty(name="Mode",
                                description="",
                                items=[('ANGLE', "Angle", ""),
                                       ('WEIGHT', "Weight", "")],
                                default='ANGLE')

    add_weighten_normals_mod: BoolProperty(name="WN", default=False)
    use_harden_normals: BoolProperty(name="HN", default=True)

    helper_tab: StringProperty(name="Helper Set Category", default="MODIFIERS")

    tab: EnumProperty(name="Tab", items=settings_tabs_items)

    toolbar_category_name: StringProperty(
        name="Toolbar Category",
        default="HardOps",
        description="Name of the tab in the toolshelf in the 3d view",
        update=category_name_changed)

    bevel_loop_slide: BoolProperty(
        name="Bweight loop slide",
        default=True,
        description="loop slide")

    pie_mod_expand: BoolProperty(
        name="Pie Mod Expand",
        default=False,
        description="Expand Pie")

    right_handed: BoolProperty(
        name="Right Handed",
        default=True,
        description="Reverse The X Mirror For Right Handed People")

    BC_unlock: BoolProperty(
        name="BC",
        default=False,
        description="BC Support")

    hops_modal_help: BoolProperty(
        name="Modal Help",
        default=False,
        description="Enables help for modal operators")

    sharpness: FloatProperty(name="angle edge marks are applied to", default=radians(30), min=radians(1), max=radians(180), precision=3, unit='ROTATION')
    auto_smooth_angle: FloatProperty(name="angle edge marks are applied to", default=radians(60), min=radians(1), max=radians(180), precision=3, unit='ROTATION')


    # operators
    Hops_mirror_modes: EnumProperty(name="Mirror Modes", items=mirror_modes, default='MODIFIER')
    Hops_mirror_modes_multi: EnumProperty(name="Mirror Modes Multi", items=mirror_modes_multi, default='VIA_ACTIVE')
    Hops_mirror_direction: EnumProperty(name="Mirror Direction", items=mirror_direction, default='+')

    Hops_mirror_modal_use_cursor: BoolProperty(
        name="Modal Mirror Uess Cursor",
        default=False,
        description="uses cursor for modal mirror")

    Hops_mirror_modal_revert: BoolProperty(
        name="Modal Mirror Revert",
        default=True,
        description="reverts modal mirror")

    Hops_mirror_modal_Interface_scale: FloatProperty(
        name="Modal Mirror Interface Scale",
        description="Modal Mirror Interface Scale",
        default=0.7, min=0.1, max=50)

    Hops_gizmo_array: FloatProperty(
        name="Array gizmo",
        description="Array gizmo",
        default=0
        )

    Hops_modal_percent_scale: FloatProperty(
        name="Modal Operators Scale",
        description="Modal Operators Scale",
        default=1, min=0.001, max=100)

    # edit mode properties

    adjustbevel_use_1_segment: BoolProperty(name="use 1 segment", default=True)

    Hops_circle_size: FloatProperty(
        name="Bevel offset step",
        description="Bevel offset step",
        default=0.0001, min=0.0001)

    Hops_gizmo: BoolProperty(name="Display Mirror Gizmo", default=True)
    Hops_gizmo_fail: BoolProperty(name="gizmo failed", default=False)
    Hops_gizmo_mirror: BoolProperty(name="Display Mirror Gizmo", default=False)
    Hops_gizmo_qarray: BoolProperty(name="Display Array Gizmo", default=False)

    circle_divisions: IntProperty(name="Division Count", description="Amount Of Vert divisions for circle", default=5, min=1, max=12)

def label_row(path, prop, row, label=''):
    row.label(text=label if label else names[prop])
    row.prop(path, prop, text='')


def draw(preference, context, layout):
    layout.label(text='Hardops Properties:')
    layout.separator()
    label_row(preference.property, 'hops_modal_help', layout.row(), label='Show Help For modal Operators')
    label_row(preference.property, 'sharpness', layout.row(), label='Sharpness')
    label_row(preference.property, 'decalmachine_fix', layout.row(), label='Use Decalmachine Fix')
    label_row(preference.property, 'adaptivemode', layout.row(), label='Use Adaptive Mode')
    label_row(preference.property, 'adaptiveoffset', layout.row(), label='Use Adaptive Offset')
    label_row(preference.property, 'adaptivewidth', layout.row(), label='Use Adaptive Width')
    label_row(preference.property, 'auto_bweight', layout.row(), label='Use Auto Bweight')
    label_row(preference.property, 'bevel_profile', layout.row(), label='Bevel Profile')
    label_row(preference.property, 'circle_divisions', layout.row(), label='Amount Of Vert divisions for circle')
    layout.separator()
    label_row(preference.property, 'debug', layout.row(), label='debug')
    layout.separator()
    if get_preferences().property.debug:
        label_row(preference.property, 'show_presets', layout.row(), label='show_presets')
        label_row(preference.property, 'keep_cutin_bevel', layout.row(), label='keep_cutin_bevel')
        label_row(preference.property, 'force_array_reset_on_init', layout.row(), label='force_array_reset_on_init')
        label_row(preference.property, 'force_array_apply_scale_on_init', layout.row(), label='force_array_apply_scale_on_init')
        label_row(preference.property, 'force_thick_reset_solidify_init', layout.row(), label='force_thick_reset_solidify_init')
        label_row(preference.property, 'meshclean_mode', layout.row(), label='meshclean_mode')
        label_row(preference.property, 'meshclean_dissolve_angle', layout.row(), label='meshclean_dissolve_angle')
        label_row(preference.property, 'meshclean_remove_threshold', layout.row(), label='meshclean_remove_threshold')
        label_row(preference.property, 'meshclean_unhide_behavior', layout.row(), label='meshclean_unhide_behavior')
        label_row(preference.property, 'meshclean_delete_interior', layout.row(), label='meshclean_delete_interior')
        label_row(preference.property, 'sharp_use_crease', layout.row(), label='sharp_use_crease')
        label_row(preference.property, 'sharp_use_bweight', layout.row(), label='sharp_use_bweight')
        label_row(preference.property, 'sharp_use_seam', layout.row(), label='sharp_use_seam')
        label_row(preference.property, 'sharp_use_sharp', layout.row(), label='sharp_use_sharp')
        label_row(preference.property, 'sort_modifiers', layout.row(), label='sort_modifiers')
        label_row(preference.property, 'sort_bevel_last', layout.row(), label='sort_bevel_last')
        label_row(preference.property, 'sort_bevel', layout.row(), label='sort_bevel')
        label_row(preference.property, 'sort_solidify', layout.row(), label='sort_solidify')
        label_row(preference.property, 'sort_array', layout.row(), label='sort_array')
        label_row(preference.property, 'sort_mirror', layout.row(), label='sort_mirror')
        label_row(preference.property, 'sort_weighted_normal', layout.row(), label='sort_weighted_normal')
        label_row(preference.property, 'sort_simple_deform', layout.row(), label='sort_simple_deform')
        label_row(preference.property, 'sort_triangulate', layout.row(), label='sort_triangulate')
        label_row(preference.property, 'sort_decimate', layout.row(), label='sort_decimate')
        label_row(preference.property, 'workflow', layout.row(), label='workflow')
        label_row(preference.property, 'workflow_mode', layout.row(), label='workflow_mode')
        label_row(preference.property, 'add_weighten_normals_mod', layout.row(), label='add_weighten_normals_mod')
        label_row(preference.property, 'use_harden_normals', layout.row(), label='use_harden_normals')
        label_row(preference.property, 'helper_tab', layout.row(), label='helper_tab')
        label_row(preference.property, 'tab', layout.row(), label='tab')
        label_row(preference.property, 'toolbar_category_name', layout.row(), label='toolbar_category_name')
        label_row(preference.property, 'bevel_loop_slide', layout.row(), label='bevel_loop_slide')
        label_row(preference.property, 'pie_mod_expand', layout.row(), label='pie_mod_expand')
        label_row(preference.property, 'right_handed', layout.row(), label='right_handed')
        label_row(preference.property, 'BC_unlock', layout.row(), label='BC_unlock')
        label_row(preference.property, 'auto_smooth_angle', layout.row(), label='auto_smooth_angle')
        label_row(preference.property, 'Hops_mirror_modes', layout.row(), label='Hops_mirror_modes')
        label_row(preference.property, 'Hops_mirror_modes_multi', layout.row(), label='Hops_mirror_modes_multi')
        label_row(preference.property, 'Hops_mirror_direction', layout.row(), label='Hops_mirror_direction')
        label_row(preference.property, 'Hops_mirror_modal_use_cursor', layout.row(), label='Hops_mirror_modal_use_cursor')
        label_row(preference.property, 'Hops_mirror_modal_revert', layout.row(), label='Hops_mirror_modal_revert')
        label_row(preference.property, 'Hops_mirror_modal_Interface_scale', layout.row(), label='Hops_mirror_modal_Interface_scale')
        label_row(preference.property, 'Hops_gizmo_array', layout.row(), label='Hops_gizmo_array')
        label_row(preference.property, 'Hops_modal_percent_scale', layout.row(), label='Hops_modal_percent_scale')
        label_row(preference.property, 'adjustbevel_use_1_segment', layout.row(), label='adjustbevel_use_1_segment')
        label_row(preference.property, 'Hops_circle_size', layout.row(), label='Hops_circle_size')
        label_row(preference.property, 'Hops_gizmo', layout.row(), label='Hops_gizmo')
        label_row(preference.property, 'Hops_gizmo_fail', layout.row(), label='Hops_gizmo_fail')
        label_row(preference.property, 'Hops_gizmo_mirror', layout.row(), label='Hops_gizmo_mirror')
        label_row(preference.property, 'Hops_gizmo_qarray', layout.row(), label='Hops_gizmo_qarray')
